#!/bin/bash
cd API
python manage.py runserver 0.0.0.0:10000
