from django.apps import AppConfig


class PdpapiConfig(AppConfig):
    name = 'PDPAPI'
