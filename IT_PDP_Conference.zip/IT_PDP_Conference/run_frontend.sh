80#!/bin/bash
cd website
python manage.py runserver 0.0.0.0:80
